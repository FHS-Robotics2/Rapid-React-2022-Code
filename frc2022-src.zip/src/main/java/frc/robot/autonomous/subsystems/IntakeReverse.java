package frc.robot.autonomous.subsystems;

import com.ctre.phoenix.motorcontrol.can.WPI_VictorSPX;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.utils.Motors;

public class IntakeReverse extends SubsystemBase {
    // Intake motor
    private final WPI_VictorSPX intakeMotor = Motors.m_Intake;

    // Intake subsystem
    public IntakeReverse() {

    }

    public void runIntakeRev() {
        //May need to change Speed
        intakeMotor.set(0.4);
    }

    public void stopIntakeRev() {
        intakeMotor.set(0);
    }
}