package frc.robot.autonomous.subsystems;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.utils.Motors;

public class DriveStraightSubsystem extends SubsystemBase {
  //Creates a new DriveStraightSubsystem

  Timer timer = new Timer();
  public DriveStraightSubsystem() {
    
  }

  public void driveStraight(double time, double speed){
    timer.start();//starts timer from 0 seconds
    if (timer.get() < time) // time is a double in terms of seconds
    {
      Motors.drive.arcadeDrive(speed,0); // move robot at this speed with/out curve
    }

    Timer.delay(0.005); //does nothing for 5 seconds but helps refresh motors in loop
    timer.stop();
  }

  public void stopDrivingStraight(){
    Motors.drive.arcadeDrive(0,0);
  }

  @Override
  public void periodic(){
    
  }
}