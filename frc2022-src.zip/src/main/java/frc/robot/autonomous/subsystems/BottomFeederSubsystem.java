package frc.robot.autonomous.subsystems;

import com.ctre.phoenix.motorcontrol.can.WPI_VictorSPX;

import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.utils.Motors;

public class BottomFeederSubsystem extends SubsystemBase {

  //Creates a new BottomFeedSubsystem

  WPI_VictorSPX feedMotor = Motors.m_TriBelt;

  public BottomFeederSubsystem(){
    
  }

  public void runFeed(double motorSpeed){
    feedMotor.set(-motorSpeed);
  }

  public void stopFeed(){
    feedMotor.set(0);
  }

  @Override
  public void periodic(){
    
  }
}