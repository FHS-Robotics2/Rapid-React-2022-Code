package frc.robot.autonomous.commands.groups;

import edu.wpi.first.wpilibj2.command.SequentialCommandGroup;
import frc.robot.autonomous.commands.Aim;
import frc.robot.autonomous.commands.DriveStraight;
import frc.robot.autonomous.commands.RotateToAngle;
import frc.robot.autonomous.subsystems.AimSubsystem;
import frc.robot.autonomous.subsystems.BottomFeederSubsystem;
import frc.robot.autonomous.subsystems.TopFeederSubsystem;
import frc.robot.autonomous.subsystems.DriveStraightSubsystem;
import frc.robot.autonomous.subsystems.ShooterSubsystem;

// Goal Auto

public class GoalAuto extends SequentialCommandGroup{

  public GoalAuto(DriveStraightSubsystem s_Straight, AimSubsystem s_Aim, ShooterSubsystem s_Shooter, 
          TopFeederSubsystem s_TopFeeder, BottomFeederSubsystem s_BottomFeeder){
    addCommands(new DriveStraight(s_Straight), new RotateToAngle(90), new Aim(s_Aim), 
              new ShootAuto(s_Shooter, s_TopFeeder, s_BottomFeeder));
  }
}
