package frc.robot.autonomous.commands;

import edu.wpi.first.wpilibj2.command.CommandBase;
import frc.robot.autonomous.subsystems.IntakeSubsystem;

public class Intake extends CommandBase {
  /**
   * Creates a new Intake.
   */

  private final IntakeSubsystem s_intake;

  public Intake(IntakeSubsystem s_intake){
    this.s_intake = s_intake;
    addRequirements(s_intake);
  }

  @Override
  public void initialize(){
    
  }

  @Override
  public void execute(){
    s_intake.runIntake();
  }

  @Override
  public void end(boolean interrupted){
    s_intake.stopIntake();
  }

  @Override
  public boolean isFinished(){
    return false;
  }
}