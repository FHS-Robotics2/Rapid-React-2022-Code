package frc.robot.autonomous.commands.groups;

import edu.wpi.first.wpilibj2.command.SequentialCommandGroup;
import frc.robot.autonomous.commands.BottomFeed;
import frc.robot.autonomous.commands.TopFeed;
import frc.robot.autonomous.commands.Shooter;
import frc.robot.autonomous.subsystems.BottomFeederSubsystem;
import frc.robot.autonomous.subsystems.TopFeederSubsystem;
import frc.robot.autonomous.subsystems.ShooterSubsystem;

public class ShootAuto extends SequentialCommandGroup{

  //Creates a new AutoShoot

  public ShootAuto (ShooterSubsystem s_aim, TopFeederSubsystem s_topFeeder, BottomFeederSubsystem s_bottomFeeder){

        super(new Shooter(s_aim), new TopFeed(s_topFeeder), new BottomFeed(s_bottomFeeder));
  }
}