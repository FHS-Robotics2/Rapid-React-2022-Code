package frc.robot.autonomous.commands;

import edu.wpi.first.wpilibj2.command.CommandBase;
import frc.robot.autonomous.subsystems.AimSubsystem;

/**
 * Aim
 */

public class Aim extends CommandBase {

    private final AimSubsystem s_aim;
  
    public Aim(AimSubsystem s_aim){
      this.s_aim = s_aim;
      addRequirements(s_aim);
    }

    @Override
    public void initialize(){

    }

    @Override
    public void execute(){
      s_aim.turnToTarget();
    }

    public void end(final boolean interrupted){
      s_aim.stopAiming();
    }

    @Override
    public boolean isFinished(){
      return false;
    }
    
}
