package frc.robot.autonomous.commands;

import edu.wpi.first.wpilibj2.command.CommandBase;
import frc.robot.autonomous.subsystems.ShooterSubsystem;

public class Shooter extends CommandBase{

  //Creates a new Shooter

  private final ShooterSubsystem s_shooter;

  public Shooter(ShooterSubsystem s_shooter){

    this.s_shooter = s_shooter;
    addRequirements(s_shooter);

  }

  @Override
  public void initialize(){
    //Note runShooter value represents motor capacity
    //runs at 100%
    s_shooter.runShooter(1);
  }

  @Override
  public void execute(){
    //Note runShooter Value significance Unknown, will have to find experimental data.

    s_shooter.runShooter(1);
  }
  @Override
  public void end(boolean interrupted){
    s_shooter.stopShooter();
  }

  //Returns true when the command should end

  @Override 
  public boolean isFinished(){
    return false;
    }
}