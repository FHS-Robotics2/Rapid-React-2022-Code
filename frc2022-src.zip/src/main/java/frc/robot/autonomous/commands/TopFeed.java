package frc.robot.autonomous.commands;

import edu.wpi.first.wpilibj2.command.CommandBase;
import frc.robot.autonomous.subsystems.TopFeederSubsystem;

public class TopFeed extends CommandBase{
  //Creates a new TopFeed

  private final TopFeederSubsystem s_TopFeedSubsystem;

  public TopFeed(TopFeederSubsystem s_TopFeedSubsystem){
    this.s_TopFeedSubsystem = s_TopFeedSubsystem;
    addRequirements(s_TopFeedSubsystem);
  }

  @Override
  public void initialize(){
    
  }

  @Override
  public void execute(){
    //runFeed value of 0.2 is unknown (may be motor speed)
    s_TopFeedSubsystem.runFeed(0.2);
      }

  @Override
  public boolean isFinished() {
    return false;
  }
  
}