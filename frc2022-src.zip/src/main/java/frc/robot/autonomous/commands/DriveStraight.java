package frc.robot.autonomous.commands;

import edu.wpi.first.wpilibj2.command.CommandBase;
import frc.robot.autonomous.subsystems.DriveStraightSubsystem;

/**
 * DriveStraight
 */

public class DriveStraight extends CommandBase{

  /*
   * Creates a new DriveStraight
   */

  private final DriveStraightSubsystem s_straight;

  public DriveStraight(DriveStraightSubsystem s_straight){
    this.s_straight = s_straight;
    addRequirements(s_straight);
  }

  //Called when the command is initially scheduled
  @Override
  public void initialize() {
    //driveStraight uses method from subsystem that originally uses values (2,0.5), dont know what they mean yet but will use experiemental 
    s_straight.driveStraight(2,0.5);
  }

  @Override
  public void execute(){
    
  }

  @Override
  public void end(boolean interrupted){
      s_straight.stopDrivingStraight();
  }

  @Override
  public boolean isFinished(){
      return false;
  }
}