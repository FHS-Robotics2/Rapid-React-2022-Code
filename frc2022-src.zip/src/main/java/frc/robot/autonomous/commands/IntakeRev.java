package frc.robot.autonomous.commands;

import edu.wpi.first.wpilibj2.command.CommandBase;
import frc.robot.autonomous.subsystems.IntakeReverse;

public class IntakeRev extends CommandBase {
  /**
   * Creates a new Intake.
   */

  private final IntakeReverse m_reverse;

  public IntakeRev(IntakeReverse m_reverse){
    this.m_reverse = m_reverse;
    addRequirements(m_reverse);
  }

  @Override
  public void initialize(){
    
  }

  @Override
  public void execute(){
    m_reverse.runIntakeRev();
  }

  @Override
  public void end(boolean interrupted){
    m_reverse.stopIntakeRev();
  }

  @Override
  public boolean isFinished(){
    return false;
  }
}