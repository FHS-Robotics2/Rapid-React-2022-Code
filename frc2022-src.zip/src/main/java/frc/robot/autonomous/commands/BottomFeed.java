package frc.robot.autonomous.commands;

import edu.wpi.first.wpilibj2.command.CommandBase;
import frc.robot.autonomous.subsystems.BottomFeederSubsystem;


public class BottomFeed extends CommandBase{
  /**
   * Creates a new BottomFeed.
   */
  
private final BottomFeederSubsystem s_FeedSubsystem;

  public BottomFeed(BottomFeederSubsystem s_FeedSubsystem){
    this.s_FeedSubsystem = s_FeedSubsystem;
    addRequirements(s_FeedSubsystem);
  //Use addRequirements() here to declare subsystem dependecies  
  }

  @Override
  public void initialize(){
    
  }

  @Override
  public void execute(){
    //run Feed value of last year is 0.2, dont know what it means will test.
    s_FeedSubsystem.runFeed(0.2);
  }

  @Override
  public void end(boolean interrupted){
    s_FeedSubsystem.stopFeed();
  }

  @Override
  public boolean isFinished(){
    return false;
  }
  
}