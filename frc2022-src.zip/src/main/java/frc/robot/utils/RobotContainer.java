package frc.robot.utils;

import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.RunCommand;
import edu.wpi.first.wpilibj2.command.button.JoystickButton;
import frc.robot.autonomous.commands.BottomFeed;
import frc.robot.autonomous.commands.DriveStraight;
import frc.robot.autonomous.commands.Intake;
import frc.robot.autonomous.commands.Shooter;
import frc.robot.autonomous.commands.TopFeed;
import frc.robot.autonomous.commands.groups.ShootAuto;
import frc.robot.autonomous.commands.IntakeRev;
import frc.robot.autonomous.subsystems.IntakeReverse;
import frc.robot.autonomous.subsystems.DriveSubsystem;
import frc.robot.autonomous.subsystems.AimSubsystem;
import frc.robot.autonomous.subsystems.BottomFeederSubsystem;
import frc.robot.autonomous.subsystems.DriveStraightSubsystem;
import frc.robot.autonomous.subsystems.IntakeSubsystem;
import frc.robot.autonomous.subsystems.ShooterSubsystem;
import frc.robot.autonomous.subsystems.TopFeederSubsystem;



/**
 * RobotContainer Sets up all the commands
 */
public class RobotContainer {
// The robot's subsystems
// s stands for subsystem
  private final DriveSubsystem s_robotDrive = new DriveSubsystem();

  private final IntakeSubsystem s_intake = new IntakeSubsystem();
  private final IntakeReverse s_intakeRev = new IntakeReverse();
  private final ShooterSubsystem s_shooter = new ShooterSubsystem();
  private final TopFeederSubsystem s_topfeeder = new TopFeederSubsystem();
  private final BottomFeederSubsystem s_bottomFeeder = new BottomFeederSubsystem();
  private final AimSubsystem s_aim = new AimSubsystem();

  //Controllers
  public static XboxController dController = new XboxController(0);
  public static XboxController oController = new XboxController(1);

  //Autonomous Routine (Default Command)
  private final Command s_autoCommand = null; //ADD

  //Driver's controls- Ties Functions to Xbox Controller Buttons
  final JoystickButton intakeButton = new JoystickButton(dController, XboxController.Button.kA.value);
  //final JoystickButton cargoLifterButton = new JoystickButton(dController, XboxController.Button.kB.value);
  final JoystickButton shooterButton = new JoystickButton(dController, XboxController.Button.kY.value);
  final JoystickButton shooterButton2 = new JoystickButton(dController, XboxController.Button.kX.value);
  final JoystickButton tribeltButton = new JoystickButton(dController, XboxController.Button.kLeftBumper.value);
  final JoystickButton mainbeltButton = new JoystickButton(dController, XboxController.Button.kRightBumper.value);
  final JoystickButton TogIntakeArmButton = new JoystickButton(dController, XboxController.Button.kStart.value);
  final JoystickButton RevIntakeMotor = new JoystickButton(dController, XboxController.Button.kBack.value);
  
  public RobotContainer() {

    //Driver's Controls
    shooterButton.whenHeld(new ShootAuto(s_shooter, s_topfeeder, s_bottomFeeder));
    shooterButton2.whenHeld(new ShootAuto(s_shooter, s_topfeeder, s_bottomFeeder));
    
    //Operator's Controls
    intakeButton.whenHeld(new Intake(s_intake));
    tribeltButton.whenHeld(new BottomFeed(s_bottomFeeder));
    mainbeltButton.whenHeld(new TopFeed(s_topfeeder));
    //TogIntakeArmButton.toggleWhenPressed(new TogIntake() );
    RevIntakeMotor.whenHeld(new IntakeRev(s_intakeRev));
    

      //Default Command Set to Drive
    s_robotDrive.setDefaultCommand(new RunCommand(() -> s_robotDrive.driveRobot(dController), s_robotDrive));
  }

  
}