package frc.robot.utils;

import com.kauailabs.navx.frc.AHRS;
import edu.wpi.first.wpilibj.DriverStation;
import 
edu.wpi.first.math.controller.PIDController;
import java.util.function.DoubleConsumer;
import edu.wpi.first.wpilibj.SPI;

public class NavX{

  public AHRS ahrs;

   /* kP is Proporional coefficient
    * Ki is integral coefficient
    * Kd is the derivative coefficient
    * Kf is the feed foward term.
    */
  //!-------------REVIEW-------------!
  private final double kP = 0.03;
  private final double kI = 0.00;
  private final double kD = 0.00;
  //private final double kF = null;

  private final double kToleranceDegrees = 2.0f;

  public double rotateToAngleRate;

  private PIDController turnController;

  public void initialize() {
    try{
        ahrs = new AHRS(SPI.Port.kMXP); }
      catch (RuntimeException e) {
        DriverStation.reportError("Error intantiating navX-MXP: " + e.getMessage(), true);
        }

        turnController = new PIDController(kP, kI, kD);
                        
    turnController.enableContinuousInput(-180.0f, 180.0f);
    turnController.setIntegratorRange(-1.0,1.0);
    
turnController.setTolerance(kToleranceDegrees);
    //turnController.setContinuous(true);
    turnController.disableContinuousInput();        
      }

    public AHRS getAHRS() {
      return ahrs;
    }

    public double getkToleranceDegrees(){
      return kToleranceDegrees;
    }

    public double getRotateToAngleRate() {
        return rotateToAngleRate;
    }

    /**
     * @return the turnController
     */
    public PIDController getTurnController() {
        return turnController;
    }

    
    public void setSetpoint(double output) {
        rotateToAngleRate = output;
  
    
  }

  
}