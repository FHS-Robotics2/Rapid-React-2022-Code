package frc.robot.utils;

import com.revrobotics.CANSparkMax;
import com.revrobotics.ColorSensorV3;
import com.revrobotics.RelativeEncoder;
import edu.wpi.first.wpilibj.I2C;

public class Sensors {
        private static CANSparkMax leftNeo;
        private static CANSparkMax rightNeo;
        
        private static final I2C.Port i2cPort = I2C.Port.kOnboard;
        private static ColorSensorV3 colorSensor;

        public static void initialize(){
            leftNeo = Motors.m_LeadShooterNeo;
            rightNeo = Motors.m_FollowerShooterNeo;
            colorSensor = new ColorSensorV3(i2cPort);
        }
}