package frc.robot.utils;

import com.ctre.phoenix.motorcontrol.can.WPI_VictorSPX;
import com.revrobotics.CANSparkMax;
import com.revrobotics.CANSparkMaxLowLevel.MotorType;

import edu.wpi.first.wpilibj.motorcontrol.MotorControllerGroup;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;

public class Motors{
  //MotorName Meaning Lft= Left, FNT = Front, Rgt = Right, BCK = Back
  //DriveTrain________________________________________________________
  private static WPI_VictorSPX m_LftFNT;
  private static WPI_VictorSPX m_LftBCK;
  private static WPI_VictorSPX m_RgtFNT;
  private static WPI_VictorSPX m_RgtBCK;

  private static MotorControllerGroup left;
  private static MotorControllerGroup right;
  public static DifferentialDrive drive;

  //INTAKE________________________________________________________

  public static WPI_VictorSPX m_Intake;

  //BOTTOM FEED (Triangle belt) __________________________________

  public static WPI_VictorSPX m_TriBelt;

  //Cargo Elevator Belt (main)____________________________________

  public static WPI_VictorSPX m_MainEBelt;

  //Shooter Wheel

  public static CANSparkMax m_LeadShooterNeo;
  public static CANSparkMax m_FollowerShooterNeo;


  /*VictorLftFnt
  VictorLftBck
  VictorRgtFnt
  VictorRgtBck */
  public static void initialize (){
    m_LftFNT = new WPI_VictorSPX(RobotMap.VictorLftFnt.getPin());
    m_LftBCK = new WPI_VictorSPX(RobotMap.VictorLftBck.getPin());
    m_RgtFNT = new WPI_VictorSPX(RobotMap.VictorRgtFnt.getPin());
    m_RgtBCK = new WPI_VictorSPX(RobotMap.VictorRgtBck.getPin());

    left = new MotorControllerGroup(m_LftFNT, m_LftBCK);
    right = new MotorControllerGroup(m_RgtFNT, m_RgtBCK);
    drive = new DifferentialDrive(left, right);
    drive.setSafetyEnabled(false);

    m_Intake = new WPI_VictorSPX(RobotMap.INTAKE_Motor.getPin());

    m_TriBelt = new WPI_VictorSPX(RobotMap.VictorTriBelt.getPin());
    m_MainEBelt = new WPI_VictorSPX(RobotMap.VictorMainBelt.getPin());

    
    m_LeadShooterNeo = new CANSparkMax(RobotMap.LeadShooterNeo.getPin(), MotorType.kBrushless);
    m_FollowerShooterNeo = new CANSparkMax(RobotMap.FollowShooterNeo.getPin(), MotorType.kBrushless);

    m_LeadShooterNeo.restoreFactoryDefaults();
    m_FollowerShooterNeo.restoreFactoryDefaults();

    m_FollowerShooterNeo.follow(m_LeadShooterNeo);

    left = new MotorControllerGroup(m_LftFNT, m_LftBCK);
    right = new MotorControllerGroup(m_RgtFNT, m_RgtBCK);
    drive = new DifferentialDrive(left, right);
    drive.setSafetyEnabled(false);



    
  }
  
}

